"""Persistent project terminal dialog for mhm_qgis."""
from __future__ import annotations

import contextlib
import os
import shlex
import signal
import sys
import uuid

from qgis.PyQt import QtCore, QtGui, QtWidgets

from ..bindings.project_terminal import bind as bind_terminal
from ..ui import load_form

Ui_ProjectTerminalDialog = load_form("project_terminal_dialog.ui")


class ProjectTerminalDialog(QtWidgets.QDialog, Ui_ProjectTerminalDialog):
    """A small persistent shell session shown in a reusable dialog."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, False)

        self._cwd = None
        self._history = []
        self._history_index = 0
        self._command_marker = ""
        self._command_buffer = ""
        self._command_callback = None
        self._process = QtCore.QProcess(self)
        self._process.setProcessChannelMode(QtCore.QProcess.ProcessChannelMode.MergedChannels)
        self._process.readyReadStandardOutput.connect(self._read_output)
        self._process.finished.connect(self._process_finished)
        self._process.errorOccurred.connect(self._process_error)

        font = QtGui.QFont("Monospace")
        font.setStyleHint(QtGui.QFont.StyleHint.TypeWriter)
        self.output.setFont(font)
        self.command_edit.installEventFilter(self)
        bind_terminal(self)

    def show_for_directory(self, cwd: str) -> bool:
        """Show the terminal and ensure its shell is in ``cwd``."""
        if not self.ensure_session(cwd):
            self.show()
            self.raise_()
            self.activateWindow()
            return False
        self.show()
        self.raise_()
        self.activateWindow()
        self.command_edit.setFocus()
        return True

    def run_command(
            self,
            command: str,
            cwd: str | None = None,
            show: bool = True,
            on_finished=None) -> bool:
        """Run a command in the persistent shell session."""
        if on_finished is not None and self._command_marker:
            return False
        if cwd is not None and not self.ensure_session(cwd):
            return False
        if cwd is None and not self.is_running():
            start_cwd = self._cwd or os.getcwd()
            if not self.ensure_session(start_cwd):
                return False
        if show:
            self.show_for_directory(cwd or self._cwd or os.getcwd())
        if on_finished is None:
            self._write_command(command)
            return True
        self._command_marker = f"__MHM_QGIS_DONE_{uuid.uuid4().hex}__="
        self._command_callback = on_finished
        self._append_text(f"$ {command}\n")
        tracked = (
            f"{command}\r\necho {self._command_marker}%errorlevel%\r\n"
            if os.name == "nt"
            else f"{command}\nprintf '\\n{self._command_marker}%s\\n' $?\n"
        )
        self._process.write(tracked.encode("utf-8"))
        return True

    def ensure_session(self, cwd: str) -> bool:
        """Start or reuse the shell session for the requested directory."""
        cwd = os.path.abspath(cwd)
        if self.is_running():
            if self._cwd != cwd:
                self._write_command(self._cd_command(cwd))
                self._cwd = cwd
            return True

        self._cwd = cwd
        self._append_text(f"Starting terminal session in {cwd}\n")
        program, args = self._shell_command()
        self._process.setWorkingDirectory(cwd)
        self._process.start(program, args)
        if not self._process.waitForStarted(3000):
            self._append_text(f"Could not start shell: {program}\n")
            return False
        return True

    def is_running(self) -> bool:
        """Return whether the backing shell process is alive."""
        return self._process.state() != QtCore.QProcess.ProcessState.NotRunning

    def command_running(self) -> bool:
        """Return whether a tracked command has not reported its exit code."""
        return bool(self._command_marker)

    def stop(self) -> None:
        """Stop the shell and its current command before the plugin exits."""
        if not self.is_running():
            return
        if os.name == "posix":
            with contextlib.suppress(ProcessLookupError):
                os.killpg(int(self._process.processId()), signal.SIGTERM)
        else:
            self._process.kill()
        QtCore.QTimer.singleShot(2000, self._kill_if_running)

    def _kill_if_running(self):
        if not self.is_running():
            return
        if os.name == "posix":
            with contextlib.suppress(ProcessLookupError):
                os.killpg(int(self._process.processId()), signal.SIGKILL)
        else:
            self._process.kill()

    def send_current_command(self) -> None:
        """Send the command line contents to the shell."""
        command = self.command_edit.text()
        if not command.strip():
            return
        if not self.is_running():
            self.ensure_session(self._cwd or os.getcwd())
        self._history.append(command)
        self._history_index = len(self._history)
        self.command_edit.clear()
        self._write_command(command)

    def eventFilter(self, watched, event):
        """Provide a minimal command history for the input line."""
        if watched is self.command_edit and event.type() == QtCore.QEvent.Type.KeyPress:
            if event.key() == QtCore.Qt.Key.Key_Up:
                self._show_history(-1)
                return True
            if event.key() == QtCore.Qt.Key.Key_Down:
                self._show_history(1)
                return True
        return super().eventFilter(watched, event)

    def closeEvent(self, event):
        """Hide the dialog without stopping the shell process."""
        event.ignore()
        self.hide()

    def reject(self) -> None:
        """Hide on Escape/window close instead of ending the shell."""
        self.hide()

    def _shell_command(self) -> tuple[str, list[str]]:
        if os.name == "nt":
            return os.environ.get("COMSPEC", "cmd.exe"), []
        shell = os.environ.get("SHELL", "/bin/bash")
        return sys.executable, [
            "-c", "import os,sys; os.setsid(); os.execvp(sys.argv[1], sys.argv[1:])",
            shell,
        ]

    def _cd_command(self, cwd: str) -> str:
        if os.name == "nt":
            return f'cd /d "{cwd}"'
        return f"cd {shlex.quote(cwd)}"

    def _write_command(self, command: str) -> None:
        if not self.is_running():
            self._append_text("No active shell session.\n")
            return
        self._append_text(f"$ {command}\n")
        self._process.write((command + "\n").encode("utf-8"))

    def _read_output(self) -> None:
        data = bytes(self._process.readAllStandardOutput())
        if not data:
            return
        self._consume_output(data.decode("utf-8", errors="replace"))

    def _consume_output(self, text):
        """Append shell output and resolve a tracked command marker."""
        if not self._command_marker:
            self._append_text(text)
            return
        self._command_buffer += text
        marker_at = self._command_buffer.find(self._command_marker)
        if marker_at < 0:
            keep = len(self._command_marker) + 12
            if len(self._command_buffer) > keep:
                self._append_text(self._command_buffer[:-keep])
                self._command_buffer = self._command_buffer[-keep:]
            return
        line_end = self._command_buffer.find("\n", marker_at)
        if line_end < 0:
            return
        self._append_text(self._command_buffer[:marker_at])
        status = self._command_buffer[
            marker_at + len(self._command_marker):line_end
        ].strip()
        remainder = self._command_buffer[line_end + 1:]
        callback = self._command_callback
        self._command_marker = ""
        self._command_buffer = ""
        self._command_callback = None
        if remainder:
            self._append_text(remainder)
        callback(int(status) if status.lstrip("-").isdigit() else -1)

    def _process_finished(self, exit_code, exit_status) -> None:
        self._finish_pending_command(exit_code)
        self._append_text(f"\nShell exited with code {exit_code}.\n")

    def _process_error(self, error) -> None:
        self._finish_pending_command(-1)
        self._append_text(f"Shell error: {self._process.errorString()}\n")

    def _finish_pending_command(self, exit_code):
        if self._command_buffer:
            self._append_text(self._command_buffer)
        callback = self._command_callback
        self._command_marker = ""
        self._command_buffer = ""
        self._command_callback = None
        if callback is not None:
            callback(int(exit_code))

    def _append_text(self, text: str) -> None:
        cursor = self.output.textCursor()
        cursor.movePosition(QtGui.QTextCursor.MoveOperation.End)
        cursor.insertText(text)
        self.output.setTextCursor(cursor)
        self.output.ensureCursorVisible()

    def _show_history(self, offset: int) -> None:
        if not self._history:
            return
        self._history_index = max(
            0,
            min(len(self._history), self._history_index + offset),
        )
        if self._history_index == len(self._history):
            self.command_edit.clear()
        else:
            self.command_edit.setText(self._history[self._history_index])
